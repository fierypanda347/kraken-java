import com.sun.tools.doclets.Taglet;
import com.sun.javadoc.*;
import java.util.Map;

public class ExperimentalTaglet implements Taglet {
    
    private static final String NAME = "status.experimental";
    

    public String getName() {
        return NAME;
    }
    

    public boolean inField() {
        return true;
    }

    
    public boolean inConstructor() {
        return true;
    }
    

    public boolean inMethod() {
        return true;
    }
    

    public boolean inOverview() {
        return false;
    }


    public boolean inPackage() {
        return true;
    }


    public boolean inType() {
        return true;
    }
    

    public boolean isInlineTag() {
        return false;
    }
    

    public static void register(Map tagletMap) {
        tagletMap.put(NAME, new ExperimentalTaglet());
    }


    public String toString(Tag tag) {
        return "<DT><B>Status:</B><DD>" +
               "<font color=red>EXPERIMENTAL</font>.  Drastic, incompatible changes may be introduced in the " +
               "future.  You have been warned." +
               "</DD>\n";
   }
    

    public String toString(Tag[] tags) {
        if (tags.length > 0)
            return toString((Tag) null);
        else
            return null;
    }
}



