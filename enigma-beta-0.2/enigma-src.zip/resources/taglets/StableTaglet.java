import com.sun.tools.doclets.Taglet;
import com.sun.javadoc.*;
import java.util.Map;

public class StableTaglet implements Taglet {
    private static final String NAME = "status.stable";

    
    public String getName() {
        return NAME;
    }
    

    public boolean inField() {
        return true;
    }

    
    public boolean inConstructor() {
        return true;
    }
    

    public boolean inMethod() {
        return true;
    }
    

    public boolean inOverview() {
        return false;
    }


    public boolean inPackage() {
        return true;
    }


    public boolean inType() {
        return true;
    }
    

    public boolean isInlineTag() {
        return false;
    }
    

    public static void register(Map tagletMap) {
        tagletMap.put(NAME, new StableTaglet());
    }


    public String toString(Tag tag) {
        return "<DT><B>Status:</B><DD>" +
               "<font color=green>STABLE</font>.  No incompatible changes will be made in the future." +
               "</DD>\n";
    }
    

    public String toString(Tag[] tags) {
        if (tags.length > 0)
            return toString((Tag) null);
        else
            return null;
    }
}



