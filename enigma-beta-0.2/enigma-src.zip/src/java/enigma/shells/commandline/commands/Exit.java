package enigma.shells.commandline.commands;

import java.io.*;

public class Exit {
    public static void main(String[] arg) {
        System.exit(0);
    }
}
